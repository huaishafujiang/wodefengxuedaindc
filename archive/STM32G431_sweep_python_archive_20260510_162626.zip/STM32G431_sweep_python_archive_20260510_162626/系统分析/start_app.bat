python main.py
pause
